// Supabase Edge Function: claim-pending-payment
// Called from dashboard.html right after login. If this user paid before
// they had an account (matched by email), this applies that payment now.
//
// Deploy: supabase functions deploy claim-pending-payment

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const admin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

const PLAN_TO_TIER: Record<string, { tier: string; days: number }> = {
  starter: { tier: "growth", days: 30 },
  premium: { tier: "premium", days: 90 },
};

Deno.serve(async (req) => {
  // The caller must be logged in — verify their access token.
  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) return new Response("Unauthorized", { status: 401 });

  const { data: userData, error: userErr } = await admin.auth.getUser(token);
  if (userErr || !userData?.user) {
    return new Response("Unauthorized", { status: 401 });
  }

  const user = userData.user;
  const email = (user.email || "").toLowerCase();

  const { data: pending } = await admin
    .from("pending_payments")
    .select("*")
    .eq("email", email)
    .eq("claimed", false);

  if (!pending || pending.length === 0) {
    return new Response(JSON.stringify({ claimed: false }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    });
  }

  // If more than one unclaimed payment exists, apply the highest tier.
  const best = pending.sort((a, b) => {
    const rank = (p: string) => (p === "premium" ? 2 : 1);
    return rank(b.plan) - rank(a.plan);
  })[0];

  const mapped = PLAN_TO_TIER[best.plan];
  if (mapped) {
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + mapped.days);

    await admin
      .from("profiles")
      .update({
        membership_tier: mapped.tier,
        subscription_status: "active",
        subscription_end_date: endDate.toISOString(),
      })
      .eq("id", user.id);

    await admin
      .from("payments")
      .update({ user_id: user.id })
      .eq("paystack_reference", best.paystack_reference);
  }

  await admin
    .from("pending_payments")
    .update({ claimed: true })
    .in(
      "id",
      pending.map((p) => p.id),
    );

  return new Response(JSON.stringify({ claimed: true, plan: best.plan }), {
    headers: { "Content-Type": "application/json" },
    status: 200,
  });
});
