-- Payment gating for compay.pro
-- Run this in the Supabase SQL editor (or via `supabase db push`).

-- Ledger of every processed Paystack payment, keyed by reference so the
-- webhook can safely be retried by Paystack without double-applying a tier.
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  paystack_reference text unique not null,
  email text not null,
  amount numeric not null,          -- in the currency's smallest unit (kobo / cents)
  currency text not null,
  plan text not null,               -- 'starter' | 'premium' | 'business_session'
  user_id uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- Payments that arrive for an email with no matching Supabase account yet.
-- Claimed automatically the next time that email logs in (see claim-pending-payment).
create table if not exists public.pending_payments (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  plan text not null,
  paystack_reference text unique not null,
  claimed boolean not null default false,
  created_at timestamptz not null default now()
);

-- Safe to run even if these columns already exist on your profiles table.
alter table public.profiles
  add column if not exists subscription_status text default 'inactive',
  add column if not exists subscription_end_date timestamptz;

-- Row Level Security: users may only ever read their own payment history.
alter table public.payments enable row level security;
create policy if not exists "Users read own payments"
  on public.payments for select
  using (auth.uid() = user_id);

-- pending_payments and profiles updates are only ever written by the
-- Edge Functions below, using the service role key — no anon/public policy
-- is added for INSERT/UPDATE on either table, which keeps tier changes
-- impossible to fake from the browser.
