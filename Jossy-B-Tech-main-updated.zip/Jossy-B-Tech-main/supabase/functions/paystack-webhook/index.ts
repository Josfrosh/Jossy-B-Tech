// Supabase Edge Function: paystack-webhook
// Receives Paystack's `charge.success` event, verifies it really came from
// Paystack, and updates the paying user's membership tier in `profiles`.
//
// Deploy:   supabase functions deploy paystack-webhook --no-verify-jwt
// Secrets:  supabase secrets set PAYSTACK_SECRET_KEY=sk_live_xxx
// Register: Paystack Dashboard -> Settings -> API Keys & Webhooks
//           -> Webhook URL: https://<project-ref>.functions.supabase.co/paystack-webhook

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const PAYSTACK_SECRET_KEY = Deno.env.get("PAYSTACK_SECRET_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

// Map what was actually charged to a plan + tier + access window.
// Adjust the amounts here if your Paystack prices ever change.
function resolvePlan(amount: number, currency: string) {
  if (currency === "NGN" && amount === 500000) {
    return { plan: "starter", tier: "growth", days: 30 };
  }
  if (currency === "NGN" && amount === 1200000) {
    return { plan: "premium", tier: "premium", days: 90 };
  }
  if (currency === "USD" && amount === 5000) {
    // $50.00 Business Development strategy session — one-off, not a tier.
    return { plan: "business_session", tier: null, days: 0 };
  }
  return null;
}

async function verifySignature(rawBody: string, signature: string | null) {
  if (!signature) return false;
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(PAYSTACK_SECRET_KEY),
    { name: "HMAC", hash: "SHA-512" },
    false,
    ["sign"],
  );
  const mac = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody));
  const hex = Array.from(new Uint8Array(mac))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return hex === signature;
}

Deno.serve(async (req) => {
  const rawBody = await req.text();
  const signature = req.headers.get("x-paystack-signature");

  if (!(await verifySignature(rawBody, signature))) {
    return new Response("Invalid signature", { status: 401 });
  }

  const event = JSON.parse(rawBody);
  if (event.event !== "charge.success") {
    return new Response("Ignored (not a successful charge)", { status: 200 });
  }

  const data = event.data;
  const reference: string = data.reference;
  const email: string = (data.customer?.email || "").toLowerCase();
  const amount: number = data.amount;
  const currency: string = data.currency;

  const resolved = resolvePlan(amount, currency);
  if (!resolved) {
    console.warn("Unrecognised amount/currency on charge:", amount, currency, reference);
    return new Response("Unrecognised plan — logged for review", { status: 200 });
  }

  // Idempotency: Paystack may retry the same webhook; never apply it twice.
  const { data: already } = await supabase
    .from("payments")
    .select("id")
    .eq("paystack_reference", reference)
    .maybeSingle();
  if (already) {
    return new Response("Already processed", { status: 200 });
  }

  // Find the Supabase account for this email, if one exists.
  const { data: userPage } = await supabase.auth.admin.listUsers({ perPage: 1000 });
  const matchedUser = userPage?.users?.find(
    (u) => (u.email || "").toLowerCase() === email,
  );

  await supabase.from("payments").insert({
    paystack_reference: reference,
    email,
    amount,
    currency,
    plan: resolved.plan,
    user_id: matchedUser?.id ?? null,
  });

  if (resolved.plan === "business_session") {
    // One-off paid appointment — logged above, no tier change needed.
    return new Response("Booking recorded", { status: 200 });
  }

  if (!matchedUser) {
    // Paid before creating an account — park it to be claimed on next login.
    await supabase.from("pending_payments").insert({
      email,
      plan: resolved.plan,
      paystack_reference: reference,
    });
    return new Response("Pending — no matching account yet", { status: 200 });
  }

  const endDate = new Date();
  endDate.setDate(endDate.getDate() + resolved.days);

  await supabase
    .from("profiles")
    .update({
      membership_tier: resolved.tier,
      subscription_status: "active",
      subscription_end_date: endDate.toISOString(),
    })
    .eq("id", matchedUser.id);

  return new Response("OK", { status: 200 });
});
